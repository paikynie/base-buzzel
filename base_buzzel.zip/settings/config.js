const fs = require('fs')

const config = {
    owner: ["6281351692548"],
    botNumber: "-",
    setPair: "12345678",
    session: "sessions",
    staticQr: "",
    image: {
        thumbnail: "https://athars.space/uploads/eb13bbc0.jpg",
        favicon: "https://athars.space/uploads/e5204bb9.jpg"
    },
    status: {
        public: true,
        terminal: true,
        reactsw: true,
        onlyGroup: true
    },
    message: { 
        staticQr: "QRIS belum dikonfigurasi. hubungi owner.",
        loGopay: "bot belum login GoPay. owner harus login dulu dengan .gopay",
        example: "example: ",
        admin: "khusus admin",
        group: "khusus group",
        owner: "khusus owner"
    },
    api: {
        baseurl: "https://kyuu2nd.dev/",
        apikey: null
    },
    sticker: {
        packname: "only",
        author: "kyuu2nd.dev"
    }
}

module.exports = config;

let file = require.resolve(__filename)
require('fs').watchFile(file, () => {
  require('fs').unwatchFile(file)
  console.log('\x1b[0;32m'+__filename+' \x1b[1;32mupdated!\x1b[0m')
  delete require.cache[file]
  require(file)
})