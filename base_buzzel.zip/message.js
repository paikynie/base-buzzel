const config = require('./settings/config');
const fs = require('fs');
const crypto = require("crypto")
const path = require("path")
const os = require('os');
const axios = require('axios')
const chalk = require("chalk")
const FormData = require('form-data');
const {
    exec
} = require('child_process');

const {
    generateWAMessageFromContent,
    prepareWAMessageMedia,
    getContentType
} = require("@whiskeysockets/baileys");
const {
    unlimitedAIChat,
    capcutdl
} = require("./library/kyuu2nd")
const {
    getGroupSetting,
    setGroupSetting
} = require('./library/_function/group');
const {
    getSession,
    setSession,
    deleteSession,
    getSessionsAll
} = require('./library/_function/gopay');
const {
    addCatalog,
    addStock,
    buyProduct,
    getAllCatalog,
    getProductByKey,
    deleteCatalog
} = require('./library/_function/products');
const {
    AIRich
} = require('./library/_function/MessageBuilder')
const {
    calculatePriceWithFee,
    isGopayReady,
    refreshAccessToken,
    deleteMessage,
    checkPaymentStatus
} = require('./library/_function/GopayStore');
const {
    getKirannStatus,
    setKirannStatus,
    deleteKirannStatus
} = require('./library/_function/kirann');

module.exports = sock = async (sock, m, chatUpdate, store) => {
    try {
        const body = (
            m.mtype === "conversation" ? m.message.conversation :
            m.mtype === "imageMessage" ? m.message.imageMessage.caption :
            m.mtype === "videoMessage" ? m.message.videoMessage.caption :
            m.mtype === "extendedTextMessage" ? m.message.extendedTextMessage.text :
            m.mtype === "buttonsResponseMessage" ? m.message.buttonsResponseMessage.selectedButtonId :
            m.mtype === "listResponseMessage" ? m.message.listResponseMessage.singleSelectReply.selectedRowId :
            m.mtype === "templateButtonReplyMessage" ? m.message.templateButtonReplyMessage.selectedId :
            m.mtype === "interactiveResponseMessage" ? JSON.parse(m.msg.nativeFlowResponseMessage.paramsJson).id :
            m.mtype === "templateButtonReplyMessage" ? m.msg.selectedId :
            m.mtype === "messageContextInfo" ? m.message.buttonsResponseMessage?.selectedButtonId ||
            m.message.listResponseMessage?.singleSelectReply.selectedRowId || m.text : ""
        );

        const TypeMess = getContentType(m?.message);
        const reactions = TypeMess == "reactionMessage" ? m?.message[TypeMess]?.text : false;

        const sender = m.key.fromMe ? sock.user.id.split(":")[0] + "@s.whatsapp.net" ||
            sock.user.id : m.key.participant || m.key.remoteJid;

        const senderNumber = sender.split('@')[0];

        const budy = (typeof m.text === 'string' ? m.text : '');
        const prefa = ["", "!", ".", ",", "🐤", "🗿"];

        const prefixRegex = /^[°zZ#$@*+,.?=''():√%!¢£¥€π¤ΠΦ_&><`™©®Δ^βα~¦|/\\©^]/;
        const prefix = prefixRegex.test(body) ? body.match(prefixRegex)[0] : '.';
        const from = m.key.remoteJid;
        const isGroup = from.endsWith("@g.us");
        const onlyGroup = config.status.onlyGroup;
        if (onlyGroup === true && !isGroup) return;
        if (onlyGroup === false && isGroup) return;

        const botNumber = await sock.decodeJid(sock.user.id);
        const isBot = botNumber.includes(senderNumber)

        const isCmd = body.startsWith(prefix);
        const command = isCmd ? body.slice(prefix.length).trim().split(' ').shift().toLowerCase() : '';
        const args = body.trim().split(/ +/).slice(1);
        const pushname = m.pushName || "No Name";
        const text = args.join(" ");
        const quoted = m.quoted ? m.quoted : m;
        const mime = (quoted.msg || quoted).mimetype || '';
        const qmsg = (quoted.msg || quoted);
        const isMedia = /image|video|sticker|audio/.test(mime);
        const groupMetadata = await sock.groupMetadata(m.chat).catch(() => ({}));
        const storeLid = sock.signalRepository?.lidMapping;
        let myPn = storeLid ? await storeLid.getPNForLID(sender) : null;
        myPn = myPn ? myPn.split(':')[0] + '@s.whatsapp.net' : null;

        const participants = groupMetadata.participants || [];
        const groupAdminsList = participants.filter(p => p.admin === 'admin' || p.admin === 'superadmin').map(p => p.phoneNumber || p.id);

        const isAdmins = groupAdminsList.includes(sender) || (myPn && groupAdminsList.includes(myPn));
        const isGroupOwner = groupMetadata.ownerPn === sender || (myPn && groupMetadata.ownerPn === myPn);
        let ownerNumber = null;
        if (myPn) {
            ownerNumber = myPn.split('@')[0];
        }
        else if (sender.includes('@s.whatsapp.net')) {
            ownerNumber = sender.split('@')[0];
        }
        else {
            ownerNumber = senderNumber;
        }
        const isOwner = config.owner.includes(ownerNumber);

        const senderPn = storeLid ? await storeLid.getPNForLID(sender) : null;
        const senderNumberClean = senderPn ? senderPn.split(':')[0].split('@')[0] : senderNumber;

        const normalizePhone = (phone) => {
            let clean = phone.replace(/\D/g, '');
            if (clean.startsWith('62')) clean = clean.substring(2);
            if (clean.startsWith('0')) clean = clean.substring(1);
            return clean;
        };

        const generateResi = () => {
            return 'QRIS-' + Date.now().toString(36).toUpperCase() + Math.random().toString(36).substring(2, 6).toUpperCase();
        };

        const staticQr = config.staticQr;

        if (isCmd) {
            console.log(chalk.hex("#6c5ce7")("# New Message"))
            console.log(`- Tanggal  : ${chalk.white(new Date().toLocaleString())}`)
            console.log(`- Pesan    : ${chalk.white(command)}`)
            console.log(`- Pengirim : ${chalk.white(pushname)}`)
            console.log(`- JID      : ${chalk.white(senderNumber)}`)
            console.log(`ㅤ\n`)
        }

        async function reply(text) {
            await sock.sendMessage(m.chat, {
                text: text,
                contextInfo: {
                    isQuestion: true,
                    isForwarded: true,
                    mentionedJid: [sender],
                    forwardingScore: 666
                }
            }, {
                quoted: m
            })
        }

        if (!global.pendingPayments) global.pendingPayments = {};

        switch (command) {
            case "listmenu":
            case "menu":
            case "list": {
                const sharp = require("sharp");
                const imageUrl = config.image.thumbnail;
                const res = await fetch(imageUrl);
                const imageBuffer = Buffer.from(await res.arrayBuffer());
                const thumbnailBuffer = await sharp(imageBuffer).resize(300, 300).jpeg({
                    quality: 80
                }).toBuffer();

                const msg = generateWAMessageFromContent(m.chat, {
                    buttonsMessage: {
                        locationMessage: {
                            degreesLatitude: 0,
                            degreesLongitude: 0,
                            name: "kyuurzy wa-bot",
                            jpegThumbnail: thumbnailBuffer
                        },
                        contentText: `Hai @${m.sender.replace(/@.+/g, '')}`,
                        footerText: "Thanks @0",
                        headerType: 6,
                        contextInfo: {
                            mentionedJid: [sender, "0@s.whatsapp.net"]
                        },
                        buttons: [{
                                buttonId: "menu1",
                                buttonText: {
                                    displayText: "#"
                                },
                                type: 1,
                                nativeFlowInfo: {
                                    name: "single_select",
                                    paramsJson: JSON.stringify({
                                        title: "MENU 1",
                                        sections: [{
                                            title: "Pilih Menu",
                                            rows: [{
                                                    title: "Menu Download",
                                                    id: prefix + "menu_download"
                                                },
                                                {
                                                    title: "Menu AI",
                                                    id: prefix + "menu_ai"
                                                },
                                                {
                                                    title: "Menu Group",
                                                    id: prefix + "menu_group"
                                                },
                                                {
                                                    title: "Menu Store",
                                                    id: prefix + "menu_store"
                                                }
                                            ]
                                        }]
                                    })
                                }
                            },
                            {
                                buttonId: "menu2",
                                buttonText: {
                                    displayText: "#"
                                },
                                type: 1,
                                nativeFlowInfo: {
                                    name: "single_select",
                                    paramsJson: JSON.stringify({
                                        title: "MENU 2",
                                        sections: [{
                                            title: "Pilih Menu",
                                            rows: [{
                                                    title: "Menu Owner",
                                                    id: prefix + "menu_owner"
                                                },
                                                {
                                                    title: "Menu Stalk",
                                                    id: prefix + "menu_stalk"
                                                },
                                                {
                                                    title: "Menu Tools",
                                                    id: prefix + "menu_tools"
                                                }
                                            ]
                                        }]
                                    })
                                }
                            }
                        ]
                    }
                }, {
                    userJid: sock.user.id,
                    quoted: m
                });

                await sock.relayMessage(msg.key.remoteJid, msg.message, {
                    messageId: msg.key.id,
                    additionalNodes: [{
                        tag: "biz",
                        attrs: {
                            actual_actors: "2",
                            host_storage: "2",
                            privacy_mode_ts: "1702827093"
                        },
                        content: [{
                                tag: "engagement",
                                attrs: {
                                    customer_service_state: "open",
                                    conversation_state: "open"
                                }
                            },
                            {
                                tag: "interactive",
                                attrs: {
                                    type: "native_flow",
                                    v: "1"
                                },
                                content: [{
                                    tag: "native_flow",
                                    attrs: {
                                        v: "9",
                                        name: "mixed"
                                    }
                                }]
                            }
                        ]
                    }]
                });
                sock.sendAudio(m.chat, fs.readFileSync("./library/audio.mp3"), {
                    ptt: true,
                    quoted: m 
                })
            }
            break

            case "menu_download": {
                const mono = "```"
                const text = `${mono}DOWNLOAD MENU

- ${prefix}capcut
- ${prefix}play
- ${prefix}tiktok
- ${prefix}igdl${mono}`

                const media = await prepareWAMessageMedia({
                    image: {
                        url: config.image.thumbnail
                    }
                }, {
                    upload: sock.waUploadToServer,
                    mediaTypeOverride: "thumbnail-link"
                });
                const img = media.imageMessage;
                const fav = await prepareWAMessageMedia({
                    image: {
                        url: config.image.favicon
                    }
                }, {
                    upload: sock.waUploadToServer,
                    mediaTypeOverride: "thumbnail-link"
                });
                const favicon = fav.imageMessage;

                const content = {
                    extendedTextMessage: {
                        text: "https://wa.me/6281351692548\n" + text,
                        matchedText: "https://wa.me/6281351692548",
                        description: "Simple WaBot",
                        title: "kyuurzy",
                        previewType: 6,
                        inviteLinkGroupTypeV2: 0,
                        jpegThumbnail: img.jpegThumbnail,
                        thumbnailDirectPath: img.directPath,
                        thumbnailSha256: img.fileSha256,
                        thumbnailEncSha256: img.fileEncSha256,
                        mediaKey: img.mediaKey,
                        mediaKeyTimestamp: img.mediaKeyTimestamp,
                        thumbnailHeight: 1024,
                        thumbnailWidth: 512,
                        type: "thumbnail",
                        contextInfo: {
                            mentionedJid: [sender, "0@s.whatsapp.net"]
                        },
                        faviconMMSMetadata: {
                            thumbnailDirectPath: favicon.directPath,
                            thumbnailSha256: favicon.fileSha256,
                            thumbnailEncSha256: favicon.fileEncSha256,
                            mediaKey: favicon.mediaKey,
                            mediaKeyTimestamp: favicon.mediaKeyTimestamp,
                            thumbnailHeight: 1440,
                            thumbnailWidth: 1440
                        }
                    }
                }

                const msg = generateWAMessageFromContent(m.chat, content, {
                    quoted: m,
                    userJid: sock.user.id
                });
                await sock.relayMessage(m.chat, msg.message, {
                    messageId: msg.key.id
                });
            }
            break

            case "menu_ai": {
                const mono = "```"
                const text = `${mono}AI MENU

- ${prefix}openai
- ${prefix}deepai
- ${prefix}blackbox
- ${prefix}perplexity
- ${prefix}kirann${mono}`

                const media = await prepareWAMessageMedia({
                    image: {
                        url: config.image.thumbnail
                    }
                }, {
                    upload: sock.waUploadToServer,
                    mediaTypeOverride: "thumbnail-link"
                });
                const img = media.imageMessage;
                const fav = await prepareWAMessageMedia({
                    image: {
                        url: config.image.favicon
                    }
                }, {
                    upload: sock.waUploadToServer,
                    mediaTypeOverride: "thumbnail-link"
                });
                const favicon = fav.imageMessage;

                const content = {
                    extendedTextMessage: {
                        text: "https://wa.me/6281351692548\n" + text,
                        matchedText: "https://wa.me/6281351692548",
                        description: "Simple WaBot",
                        title: "kyuurzy",
                        previewType: 6,
                        inviteLinkGroupTypeV2: 0,
                        jpegThumbnail: img.jpegThumbnail,
                        thumbnailDirectPath: img.directPath,
                        thumbnailSha256: img.fileSha256,
                        thumbnailEncSha256: img.fileEncSha256,
                        mediaKey: img.mediaKey,
                        mediaKeyTimestamp: img.mediaKeyTimestamp,
                        thumbnailHeight: 1024,
                        thumbnailWidth: 512,
                        type: "thumbnail",
                        contextInfo: {
                            mentionedJid: [sender, "0@s.whatsapp.net"]
                        },
                        faviconMMSMetadata: {
                            thumbnailDirectPath: favicon.directPath,
                            thumbnailSha256: favicon.fileSha256,
                            thumbnailEncSha256: favicon.fileEncSha256,
                            mediaKey: favicon.mediaKey,
                            mediaKeyTimestamp: favicon.mediaKeyTimestamp,
                            thumbnailHeight: 1440,
                            thumbnailWidth: 1440
                        }
                    }
                }

                const msg = generateWAMessageFromContent(m.chat, content, {
                    quoted: m,
                    userJid: sock.user.id
                });
                await sock.relayMessage(m.chat, msg.message, {
                    messageId: msg.key.id
                });
            }
            break

            case "menu_group": {
                const mono = "```"
                const text = `${mono}GROUP MENU

- ${prefix}hidetag
- ${prefix}tagall
- ${prefix}welcome
- ${prefix}goodbye
- ${prefix}am send/verif${mono}`

                const media = await prepareWAMessageMedia({
                    image: {
                        url: config.image.thumbnail
                    }
                }, {
                    upload: sock.waUploadToServer,
                    mediaTypeOverride: "thumbnail-link"
                });
                const img = media.imageMessage;
                const fav = await prepareWAMessageMedia({
                    image: {
                        url: config.image.favicon
                    }
                }, {
                    upload: sock.waUploadToServer,
                    mediaTypeOverride: "thumbnail-link"
                });
                const favicon = fav.imageMessage;

                const content = {
                    extendedTextMessage: {
                        text: "https://wa.me/6281351692548\n" + text,
                        matchedText: "https://wa.me/6281351692548",
                        description: "Simple WaBot",
                        title: "kyuurzy",
                        previewType: 6,
                        inviteLinkGroupTypeV2: 0,
                        jpegThumbnail: img.jpegThumbnail,
                        thumbnailDirectPath: img.directPath,
                        thumbnailSha256: img.fileSha256,
                        thumbnailEncSha256: img.fileEncSha256,
                        mediaKey: img.mediaKey,
                        mediaKeyTimestamp: img.mediaKeyTimestamp,
                        thumbnailHeight: 1024,
                        thumbnailWidth: 512,
                        type: "thumbnail",
                        contextInfo: {
                            mentionedJid: [sender, "0@s.whatsapp.net"]
                        },
                        faviconMMSMetadata: {
                            thumbnailDirectPath: favicon.directPath,
                            thumbnailSha256: favicon.fileSha256,
                            thumbnailEncSha256: favicon.fileEncSha256,
                            mediaKey: favicon.mediaKey,
                            mediaKeyTimestamp: favicon.mediaKeyTimestamp,
                            thumbnailHeight: 1440,
                            thumbnailWidth: 1440
                        }
                    }
                }

                const msg = generateWAMessageFromContent(m.chat, content, {
                    quoted: m,
                    userJid: sock.user.id
                });
                await sock.relayMessage(m.chat, msg.message, {
                    messageId: msg.key.id
                });
            }
            break

            case "menu_store": {
                const mono = "```"
                const text = `${mono}STORE MENU

- ${prefix}addstock
- ${prefix}addcatalog
- ${prefix}listcatalog
- ${prefix}delcatalog${mono}`

                const media = await prepareWAMessageMedia({
                    image: {
                        url: config.image.thumbnail
                    }
                }, {
                    upload: sock.waUploadToServer,
                    mediaTypeOverride: "thumbnail-link"
                });
                const img = media.imageMessage;
                const fav = await prepareWAMessageMedia({
                    image: {
                        url: config.image.favicon
                    }
                }, {
                    upload: sock.waUploadToServer,
                    mediaTypeOverride: "thumbnail-link"
                });
                const favicon = fav.imageMessage;

                const content = {
                    extendedTextMessage: {
                        text: "https://wa.me/6281351692548\n" + text,
                        matchedText: "https://wa.me/6281351692548",
                        description: "Simple WaBot",
                        title: "kyuurzy",
                        previewType: 6,
                        inviteLinkGroupTypeV2: 0,
                        jpegThumbnail: img.jpegThumbnail,
                        thumbnailDirectPath: img.directPath,
                        thumbnailSha256: img.fileSha256,
                        thumbnailEncSha256: img.fileEncSha256,
                        mediaKey: img.mediaKey,
                        mediaKeyTimestamp: img.mediaKeyTimestamp,
                        thumbnailHeight: 1024,
                        thumbnailWidth: 512,
                        type: "thumbnail",
                        contextInfo: {
                            mentionedJid: [sender, "0@s.whatsapp.net"]
                        },
                        faviconMMSMetadata: {
                            thumbnailDirectPath: favicon.directPath,
                            thumbnailSha256: favicon.fileSha256,
                            thumbnailEncSha256: favicon.fileEncSha256,
                            mediaKey: favicon.mediaKey,
                            mediaKeyTimestamp: favicon.mediaKeyTimestamp,
                            thumbnailHeight: 1440,
                            thumbnailWidth: 1440
                        }
                    }
                }

                const msg = generateWAMessageFromContent(m.chat, content, {
                    quoted: m,
                    userJid: sock.user.id
                });
                await sock.relayMessage(m.chat, msg.message, {
                    messageId: msg.key.id
                });
            }
            break

            case "menu_owner": {
                const mono = "```"
                const text = `${mono}OWNER MENU

- ${prefix}getbps
- ${prefix}eval
- ${prefix}backup
- ${prefix}upswgc
- ${prefix}gopay
- ${prefix}exec${mono}`

                const media = await prepareWAMessageMedia({
                    image: {
                        url: config.image.thumbnail
                    }
                }, {
                    upload: sock.waUploadToServer,
                    mediaTypeOverride: "thumbnail-link"
                });
                const img = media.imageMessage;
                const fav = await prepareWAMessageMedia({
                    image: {
                        url: config.image.favicon
                    }
                }, {
                    upload: sock.waUploadToServer,
                    mediaTypeOverride: "thumbnail-link"
                });
                const favicon = fav.imageMessage;

                const content = {
                    extendedTextMessage: {
                        text: "https://wa.me/6281351692548\n" + text,
                        matchedText: "https://wa.me/6281351692548",
                        description: "Simple WaBot",
                        title: "kyuurzy",
                        previewType: 6,
                        inviteLinkGroupTypeV2: 0,
                        jpegThumbnail: img.jpegThumbnail,
                        thumbnailDirectPath: img.directPath,
                        thumbnailSha256: img.fileSha256,
                        thumbnailEncSha256: img.fileEncSha256,
                        mediaKey: img.mediaKey,
                        mediaKeyTimestamp: img.mediaKeyTimestamp,
                        thumbnailHeight: 1024,
                        thumbnailWidth: 512,
                        type: "thumbnail",
                        contextInfo: {
                            mentionedJid: [sender, "0@s.whatsapp.net"]
                        },
                        faviconMMSMetadata: {
                            thumbnailDirectPath: favicon.directPath,
                            thumbnailSha256: favicon.fileSha256,
                            thumbnailEncSha256: fabicon.fileEncSha256,
                            mediaKey: favicon.mediaKey,
                            mediaKeyTimestamp: favicon.mediaKeyTimestamp,
                            thumbnailHeight: 1440,
                            thumbnailWidth: 1440
                        }
                    }
                }

                const msg = generateWAMessageFromContent(m.chat, content, {
                    quoted: m,
                    userJid: sock.user.id
                });
                await sock.relayMessage(m.chat, msg.message, {
                    messageId: msg.key.id
                });
            }
            break

            case "menu_stalk": {
                const mono = "```"
                const text = `${mono}STALK MENU

- ${prefix}stalk-ig
- ${prefix}stalk-mlbb
- ${prefix}stalk-ff${mono}`

                const media = await prepareWAMessageMedia({
                    image: {
                        url: config.image.thumbnail
                    }
                }, {
                    upload: sock.waUploadToServer,
                    mediaTypeOverride: "thumbnail-link"
                });
                const img = media.imageMessage;
                const fav = await prepareWAMessageMedia({
                    image: {
                        url: config.image.favicon
                    }
                }, {
                    upload: sock.waUploadToServer,
                    mediaTypeOverride: "thumbnail-link"
                });
                const favicon = fav.imageMessage;

                const content = {
                    extendedTextMessage: {
                        text: "https://wa.me/6281351692548\n" + text,
                        matchedText: "https://wa.me/6281351692548",
                        description: "Simple WaBot",
                        title: "kyuurzy",
                        previewType: 6,
                        inviteLinkGroupTypeV2: 0,
                        jpegThumbnail: img.jpegThumbnail,
                        thumbnailDirectPath: img.directPath,
                        thumbnailSha256: img.fileSha256,
                        thumbnailEncSha256: img.fileEncSha256,
                        mediaKey: img.mediaKey,
                        mediaKeyTimestamp: img.mediaKeyTimestamp,
                        thumbnailHeight: 1024,
                        thumbnailWidth: 512,
                        type: "thumbnail",
                        contextInfo: {
                            mentionedJid: [sender, "0@s.whatsapp.net"]
                        },
                        faviconMMSMetadata: {
                            thumbnailDirectPath: favicon.directPath,
                            thumbnailSha256: favicon.fileSha256,
                            thumbnailEncSha256: favicon.fileEncSha256,
                            mediaKey: favicon.mediaKey,
                            mediaKeyTimestamp: favicon.mediaKeyTimestamp,
                            thumbnailHeight: 1440,
                            thumbnailWidth: 1440
                        }
                    }
                }

                const msg = generateWAMessageFromContent(m.chat, content, {
                    quoted: m,
                    userJid: sock.user.id
                });
                await sock.relayMessage(m.chat, msg.message, {
                    messageId: msg.key.id
                });
            }
            break

            case "menu_tools": {
                const mono = "```"
                const text = `${mono}TOOLS MENU

- ${prefix}s
- ${prefix}pinterest${mono}`

                const media = await prepareWAMessageMedia({
                    image: {
                        url: config.image.thumbnail
                    }
                }, {
                    upload: sock.waUploadToServer,
                    mediaTypeOverride: "thumbnail-link"
                });
                const img = media.imageMessage;
                const fav = await prepareWAMessageMedia({
                    image: {
                        url: config.image.favicon
                    }
                }, {
                    upload: sock.waUploadToServer,
                    mediaTypeOverride: "thumbnail-link"
                });
                const favicon = fav.imageMessage;

                const content = {
                    extendedTextMessage: {
                        text: "https://wa.me/6281351692548\n" + text,
                        matchedText: "https://wa.me/6281351692548",
                        description: "Simple WaBot",
                        title: "kyuurzy",
                        previewType: 6,
                        inviteLinkGroupTypeV2: 0,
                        jpegThumbnail: img.jpegThumbnail,
                        thumbnailDirectPath: img.directPath,
                        thumbnailSha256: img.fileSha256,
                        thumbnailEncSha256: img.fileEncSha256,
                        mediaKey: img.mediaKey,
                        mediaKeyTimestamp: img.mediaKeyTimestamp,
                        thumbnailHeight: 1024,
                        thumbnailWidth: 512,
                        type: "thumbnail",
                        contextInfo: {
                            mentionedJid: [sender, "0@s.whatsapp.net"]
                        },
                        faviconMMSMetadata: {
                            thumbnailDirectPath: favicon.directPath,
                            thumbnailSha256: favicon.fileSha256,
                            thumbnailEncSha256: favicon.fileEncSha256,
                            mediaKey: favicon.mediaKey,
                            mediaKeyTimestamp: favicon.mediaKeyTimestamp,
                            thumbnailHeight: 1440,
                            thumbnailWidth: 1440
                        }
                    }
                }

                const msg = generateWAMessageFromContent(m.chat, content, {
                    quoted: m,
                    userJid: sock.user.id
                });
                await sock.relayMessage(m.chat, msg.message, {
                    messageId: msg.key.id
                });
            }
            break
            case "text2anime":
            case "animegen": {
                if (!text) return reply(config.message.example + prefix + command + " prompt");
                await m.react("👍");

                function genSessionHash(len = 10) {
                    return Math.random().toString(36).slice(2, 2 + len);
                }

                const sessionHash = genSessionHash();
                const negPrompt = "lowres, bad anatomy, bad hands, text, error, missing finger, extra digits, fewer digits, cropped, worst quality, low quality, low score, bad score, average score, signature, watermark, username, blurry";

                try {
                    const joinRes = await fetch('https://asahina2k-animagine-xl-4-0.hf.space/queue/join?__theme=system', {
                        method: 'POST',
                        headers: {
                            'content-type': 'application/json'
                        },
                        body: JSON.stringify({
                            data: [
                                text,
                                negPrompt,
                                Math.floor(Math.random() * 1e9),
                                1024,
                                1024,
                                5,
                                28,
                                "Euler a",
                                "1024 x 1024",
                                "(None)",
                                false,
                                0.55,
                                1.5,
                                true
                            ],
                            event_data: null,
                            fn_index: 5,
                            trigger_id: 43,
                            session_hash: sessionHash
                        })
                    });
                    const {
                        event_id
                    } = await joinRes.json();
                    const streamRes = await fetch(`https://asahina2k-animagine-xl-4-0.hf.space/queue/data?session_hash=${sessionHash}`, {
                        headers: {
                            'Accept': 'text/event-stream'
                        }
                    });

                    const reader = streamRes.body.getReader();
                    const decoder = new TextDecoder();

                    let imageUrl = null;

                    while (true) {
                        const {
                            value,
                            done
                        } = await reader.read();
                        if (done) break;
                        const chunk = decoder.decode(value);

                        for (const line of chunk.split('\n')) {
                            if (!line.startsWith('data: ')) continue;
                            const data = JSON.parse(line.slice(6));

                            if (data.event_id === event_id && data.success && data.output?.data?.[0]) {
                                const out = data.output.data[0];
                                if (Array.isArray(out) && out[0]?.image?.url) {
                                    imageUrl = out[0].image.url;
                                    break;
                                }
                            }
                        }
                        if (imageUrl) break;
                    }

                    if (imageUrl) {
                        await new AIRich(sock)
                            .setTitle("AI TEXT TO ANIME")
                            .addImage(imageUrl, {
                                resolveUrl: true
                            })
                            .send(m.chat, {
                                quoted: m
                            });
                        await m.react("✅");
                    }
                    else {
                        await m.react("❌");
                        reply("Gagal generate gambar");
                    }
                }
                catch (err) {
                    await m.react("❌");
                    reply(`Error: ${err.message}`);
                }
            }
            break
            case "upswgc":
            case "uploadstatus":
            case "statusgc":
            case "upstatus": {
                if (!isOwner) return reply(config.message.owner);
                if (!isGroup) return reply(config.message.group);

                await m.react("👍");
                const text = args.join(" ");

                if (text) {
                    await sock.relayMessage(m.chat, {
                        groupStatusMessageV2: {
                            message: {
                                conversation: text
                            }
                        }
                    }, {});
                    return m.react("✅");
                }

                if (!m.quoted) return reply(config.message.example + prefix + command + ` (reply pesan)`);

                let type = m.quoted.mtype || getContentType(m.quoted.message);
                let allowedTypes = [
                    "imageMessage",
                    "videoMessage",
                    "audioMessage",
                    "conversation",
                    "extendedTextMessage"
                ];

                if (!allowedTypes.includes(type)) return m.react("❌");

                let payload = JSON.parse(JSON.stringify({
                    [type]: m.quoted.message[type]
                }));

                await sock.relayMessage(m.chat, {
                    groupStatusMessageV2: {
                        message: payload
                    }
                }, {});

                return m.react("✅");
            }
            break
            case "blackbox": {
                if (!text) return reply(config.message.example + prefix + command + " pertanyaan");
                await m.react("👍");
                try {
                    const response = await axios.get(`https://kyuu2nd.dev/api/ai/blackbox?prompt=${encodeURIComponent(text)}`);
                    if (response.data && response.data.result && response.data.result.answer) {
                        reply(response.data.result.answer);
                        await m.react("✅");
                    }
                    else {
                        await m.react("❌");
                        reply("Gagal mendapatkan respon dari Blackbox AI");
                    }
                }
                catch (err) {
                    await m.react("❌");
                    reply(`Error: ${err.message}`);
                }
            }
            break
            case "delcatalog":
            case "delcat": {
                if (!isOwner) return reply(config.message.owner);
                if (!isGopayReady()) return reply(config.message.loGopay);
                if (!text) return reply(config.message.example + prefix + command + " KEY");

                const key = text.trim().toLowerCase();
                const groupId = m.chat;
                const product = getProductByKey(key, groupId);

                if (!product) return reply(`Key ${key} tidak ditemukan`);

                if (deleteCatalog(key, groupId)) {
                    reply(`Katalog dihapus:

- Title: ${product.title}
- Key: ${product.key}`);
                }
                else {
                    reply(`Gagal menghapus katalog ${key}`);
                }
            }
            break;

            case "addcatalog":
            case "addcat": {
                if (!isOwner) return reply(config.message.owner);
                if (!isGopayReady()) return reply(config.message.loGopay);
                if (!text) return reply(config.message.example + prefix + command + " TITLE|DESC|KEY|HARGA");
                const parts = text.split("|");
                if (parts.length < 4) return reply(config.message.example + prefix + command + " TITLE|DESC|KEY|HARGA");

                const title = parts[0].trim();
                const desc = parts[1].trim();
                const key = parts[2].trim().toLowerCase();
                const price = parseInt(parts[3].trim());
                const groupId = m.chat;

                if (isNaN(price)) return reply("Harga harus angka");
                if (addCatalog(title, desc, key, price, groupId)) {
                    reply(`Katalog ditambahkan:

- Title: ${title}
- Desc: ${desc}
- Key: ${key}
- Harga: Rp ${price.toLocaleString()}`);
                }
                else {
                    reply(`Key ${key} sudah ada`);
                }
            }
            break;
            case "addstock":
            case "addstok": {
                if (!isOwner) return reply(config.message.owner);
                if (!isGopayReady()) return reply(config.message.loGopay);
                if (!text) return reply(config.message.example + prefix + command + " KEY|EMAIL|PASSWORD|NOTE");
                const parts = text.split("|");
                if (parts.length < 3) return reply(config.message.example + prefix + command + " KEY|EMAIL|PASSWORD|NOTE");

                const key = parts[0].trim().toLowerCase();
                const email = parts[1].trim();
                const password = parts[2].trim();
                const note = parts[3] ? parts[3].trim() : "";
                const groupId = m.chat;

                if (addStock(key, email, password, note, groupId)) {
                    const product = getProductByKey(key, groupId);
                    reply(`Stock ditambahkan:

- Produk: ${product.title}
- Email: ${email}
- Pass: ${password}
- Note: ${note}

- Total stock: ${product.stock}`);
                }
                else {
                    reply(`Key ${key} tidak ditemukan`);
                }
            }
            break;

            case "listcatalog":
            case "listcat": {
                const groupId = m.chat;
                const catalog = getAllCatalog(groupId);
                if (catalog.length === 0) return reply("Belum ada katalog");

                let teks = "Daftar Katalog:\n\n";
                const feeAmount = Math.floor(Math.random() * 100) + 50;

                catalog.forEach((c, i) => {
                    const {
                        total,
                        fee
                    } = calculatePriceWithFee(c.price);
                    teks += `${i + 1}. ${c.title}\n`;
                    teks += `> Key: ${c.key}\n`;
                    teks += `> Harga: Rp ${c.price.toLocaleString()}\n`;
                    teks += `> Stock: ${c.stock}\n`;
                    teks += `> Terjual: ${c.sold}\n`;
                    teks += `> Desk: ${c.desc}\n\n`;
                });

                teks += `Cara beli: ${prefix}buy KEY JUMLAH
Contoh: ${prefix}buy ${catalog[0]?.key} 1`;

                reply(teks);
            }
            break;

            case "buy":
            case "buyproduct": {
                if (!text) return reply(config.message.example + prefix + command + " KEY JUMLAH");
                const args = text.trim().split(/\s+/);
                const key = args[0].toLowerCase();
                const amount = parseInt(args[1]) || 1;
                const groupId = m.chat;

                if (isNaN(amount) || amount <= 0) return reply("Jumlah tidak valid");

                const product = getProductByKey(key, groupId);
                if (!product) return reply(`Key ${key} tidak ditemukan`);
                if (product.stock < amount) return reply(`Stock tidak mencukupi. Sisa stock: ${product.stock}`);

                const {
                    total: totalPrice,
                    fee
                } = calculatePriceWithFee(product.price * amount);
                const paymentId = `${key}-${Date.now()}${Math.random().toString(36).substring(2, 6).toUpperCase()}`
                const response = await fetch(`https://kyuu2nd.dev/api/gopay/create-qris?amount=${totalPrice}&static_qr=${staticQr}`);
                const data = await response.json();

                if (data.success) {
                    let rawPhone = null;
                    const allSessions = getSessionsAll();
                    for (const [phone, session] of Object.entries(allSessions)) {
                        if (session.access_token) {
                            rawPhone = phone;
                            break;
                        }
                    }

                    if (rawPhone) {
                        const session = getSession(rawPhone);
                        if (session) {
                            session.transaksi = session.transaksi || {};
                            session.transaksi[paymentId] = {
                                url: data.result.url,
                                filename: data.result.filename,
                                created_at: data.result.created_at,
                                amount: totalPrice,
                                status: "PENDING"
                            };
                            setSession(rawPhone, session);
                        }
                    }

                    const sentMsg = await sock.sendMessage(m.chat, {
                        image: {
                            url: data.result.url
                        },
                        caption: `Pembelian:

- Produk: ${product.title}
- Jumlah: ${amount}
- Total: Rp ${totalPrice.toLocaleString()}
- Fee: Rp ${fee.toLocaleString()}

Scan QRIS untuk pembayaran.
Waktu: 3 menit
ID: ${paymentId}`
                    }, {
                        quoted: m
                    });

                    global.pendingPayments[paymentId] = {
                        key: product.key,
                        title: product.title,
                        amount: amount,
                        totalPrice: totalPrice,
                        createdAt: data.result.created_at,
                        chatId: m.chat,
                        quoted: m,
                        paymentId: paymentId,
                        messageId: sentMsg.key.id,
                        groupId: groupId
                    };

                    checkPaymentStatus(sock, paymentId);
                }
                else {
                    reply(config.message.staticQr);
                }
            }
            break;
            case "stalk-ff":
            case "freefire": {
                if (!text) return reply(config.message.example + prefix + command + " uid");

                const args = text.trim().split(/\s+/);
                let uid = args[0];
                let region = "id";

                if (args[1] && args[1].startsWith("-")) {
                    region = args[1].substring(1).toLowerCase();
                }

                if (!uid) return reply(config.message.example + prefix + command + " 5409563207");
                await m.react("👍");

                try {
                    const response = await axios.get(`https://kyuu2nd.dev/api/stalk/free-fire?uid=${uid}&region=${region}`);
                    const data = response.data;

                    if (data.status === false && data.result === "Access denied. IP not whitelisted.") {
                        await m.react("❌");
                        return reply("IP tidak di izinkan, silahkan hubungi owner");
                    }

                    if (data.status && data.result) {
                        const result = data.result;
                        const basic = result.basicInfo || {};
                        const clan = result.clanBasicInfo || {};
                        const captain = result.captainBasicInfo || {};
                        const pet = result.petInfo || {};
                        const social = result.socialInfo || {};

                        let lastLogin = basic.lastLoginAt ? new Date(parseInt(basic.lastLoginAt) * 1000).toLocaleDateString('id-ID') : "-";
                        let createAt = basic.createAt ? new Date(parseInt(basic.createAt) * 1000).toLocaleDateString('id-ID') : "-";

                        let teks = `FREE FIRE STALKER

- Nickname: ${basic.nickname || "-"}
- UID: ${basic.accountId || "-"}
- Region: ${basic.region ? basic.region.toUpperCase() : "-"}
- Level: ${basic.level || 0}
- Rank: ${basic.rank || 0}
- CS Rank: ${basic.csRank || 0}
- Liked: ${basic.liked || 0}
- Elite Pass: ${basic.hasElitePass ? "Ya" : "Tidak"}
- Last Login: ${lastLogin}
- Account Created: ${createAt}\n`;

                        if (clan.clanName) {
                            teks += `
- Clan: ${clan.clanName || "-"}
- Clan Level: ${clan.clanLevel || 0}
- Clan Captain: ${captain.nickname || "-"}\n`;
                        }

                        if (pet.id) {
                            teks += `
- Pet ID: ${pet.id}
- Pet Level: ${pet.level || 0}\n`;
                        }

                        if (social.signature && social.signature !== "ㅤㅤㅤㅤㅤㅤㅤ             ㅤ") {
                            teks += `
- Signature: ${social.signature}\n`;
                        }

                        teks += `
- Credit Score: ${result.creditScoreInfo?.creditScore || 0}`;

                        await reply(teks);
                        await m.react("✅");
                    }
                    else {
                        await m.react("❌");
                        reply("User tidak ditemukan");
                    }
                }
                catch (err) {
                    await m.react("❌");
                    reply(`Periksa ID Dengan benar atau kemungkinan API Sedang Down`);
                }
            }
            break;
            case "stalk-mlbb":
            case "mlbb": {
                if (!text) return reply(config.message.example + prefix + command + " userID serverID");

                const args = text.trim().split(/\s+/);
                let userID = args[0];
                let serverID = args[1] ? args[1].replace(/[()]/g, '') : null;

                if (!userID) return reply(config.message.example + prefix + command + " userID serverID");

                await m.react("👍");

                try {
                    const response = await axios.get(`https://kyuu2nd.dev/api/stalk/mlbb-check?userID=${userID}&serverID=${serverID || ""}`);
                    const data = response.data;

                    if (data.status === false && data.result === "Access denied. IP not whitelisted.") {
                        await m.react("❌");
                        return reply("IP tidak di izinkan, silahkan hubungi owner");
                    }

                    if (data.status && data.result) {
                        const result = data.result;

                        let diamondList = "";
                        let weeklyStatus = "";
                        let monthlyStatus = "";

                        if (result.info && result.info.diamond) {
                            for (const d of result.info.diamond) {
                                if (d.title === "Weekly Elite Bundle") {
                                    weeklyStatus = `- Weekly Elite Bundle: ${d.available ? "Tersedia" : "Tidak tersedia"}\n`;
                                }
                                else if (d.title === "Monthly Epic Bundle") {
                                    monthlyStatus = `- Monthly Epic Bundle: ${d.available ? "Tersedia" : "Tidak tersedia"}\n`;
                                }
                                else {
                                    diamondList += `- ${d.title}: ${d.available ? "Tersedia" : "Tidak tersedia"}\n`;
                                }
                            }
                        }

                        let accountList = "";
                        if (result.info && result.info.account) {
                            const acc = result.info.account;
                            accountList += `- Moonton: ${acc.Moonton || "-"}
- Google Play: ${acc["Google Play"] || "-"}
- Tiktok: ${acc.Tiktok || "-"}
- Device: ${acc.device || "-"}\n`;
                        }

                        let createdAt = result.info?.created_at;
                        if (!createdAt || createdAt === null) {
                            createdAt = "Tidak Diketahui";
                        }

                        let teks = `MLBB STALKER

- Nickname: ${result.nickname || "-"}
- User ID: ${result.userID || "-"}
- Server ID: ${result.serverID || "-"}
- Country: ${result.country || "-"}
- Account Created: ${createdAt}

> Diamond Packages:
${diamondList || "- Tidak ada data\n"}${weeklyStatus}${monthlyStatus}
> Linked Accounts:
${accountList || "- Tidak ada data"}`;

                        await reply(teks);
                        await m.react("✅");
                    }
                    else {
                        await m.react("❌");
                        reply("User tidak ditemukan");
                    }
                }
                catch (err) {
                    await m.react("❌");
                    reply(`Periksa ID Dengan Benar atau Kemungkinan API Sedang Down`);
                }
            }
            break;
            case "setppbot":
            case "setbotpp": {
                if (!isOwner) return reply(config.message.owner);
                if (!m.quoted || !/image/.test(mime)) return reply(config.message.example + prefix + command + " (reply foto)");

                let media = await sock.downloadMediaMessage(m.quoted);
                let tempPath = path.join(os.tmpdir(), `ppbot_${Date.now()}.jpg`);
                fs.writeFileSync(tempPath, media);
                await sock.updateProfilePicture(botNumber, {
                    url: tempPath
                });
                fs.unlinkSync(tempPath);
                reply("Profile picture bot berhasil diubah");
            }
            break;
            case "stalk-ig":
            case "igstalk": {
                if (!text) return reply(config.message.example + prefix + command + " username");

                const username = text.replace("@", "").trim();
                await m.react("👍");

                const generateToken = async () => {
                    const url = 'https://kyuu2nd.dev/api/tools/turnstile-min';
                    const sitekey = '0x4AAAAAAB6QhQUK_Fx885qf';
                    const targetUrl = 'https://www.dolphinradar.com/instagram-new-follow-tracker';
                    const res = await fetch(`${url}?url=${encodeURIComponent(targetUrl)}&sitekey=${sitekey}`);
                    const json = await res.json();
                    return json.result;
                };

                const fetchData = async (endpoint) => {
                    let captchaToken = await generateToken();
                    const apiUrl = `https://www.dolphinradar.com/api/ins/recent/search/${endpoint}?pageNo=1&mediaName=${username}`;
                    const headers = {
                        'User-Agent': 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/139.0.0.0 Mobile Safari/537.36',
                        'Accept': 'application/json, text/plain, */*',
                        'sec-ch-ua': '"Chromium";v="139", "Not;A=Brand";v="99"',
                        'is-free': 'true',
                        'biz-func-name': 'recent_follow',
                        'captcha-token': captchaToken,
                        'sec-ch-ua-mobile': '?1',
                        'time-zone': 'Asia/Makassar',
                        'tenantid': '6',
                        'sec-ch-ua-platform': '"Android"',
                        'sec-fetch-site': 'same-origin',
                        'sec-fetch-mode': 'cors',
                        'sec-fetch-dest': 'empty',
                        'referer': 'https://www.dolphinradar.com/instagram-new-follow-tracker',
                        'accept-language': 'id-ID,id;q=0.9,en-US;q=0.8,en;q=0.7',
                        'Cookie': '__stripe_mid=5e29e264-89d4-477a-85b9-ec00395197f6ec8be2'
                    };

                    let response = await fetch(apiUrl, {
                        method: 'GET',
                        headers: headers
                    });
                    let data = await response.json();

                    if (!data.data || !data.data.items) {
                        return null;
                    }

                    return data.data.items.map(item => item.media_name);
                };

                const [followers, following] = await Promise.all([
                    fetchData('followers'),
                    fetchData('following')
                ]);

                const now = new Date();
                const day = now.getDate();
                const month = now.getMonth() + 1;
                const year = now.getFullYear();
                const dateStr = `${day}/${month}/${year}`;

                let teks = `Instagram Stalker

Username: @${username}
Date: ${dateStr}

`;

                if (followers === null && following === null) {
                    teks += `Akun ini private atau tidak dapat diakses`;
                }
                else {
                    teks += `Followers (${followers ? followers.length : 0}):\n`;
                    teks += followers ? followers.map(f => `- @${f}`).join('\n') : "- Tidak dapat diakses";
                    teks += `\n\nFollowing (${following ? following.length : 0}):\n`;
                    teks += following ? following.map(f => `- @${f}`).join('\n') : "- Tidak dapat diakses";
                }
                await reply(teks);
            }
            break;
            case "hd":
            case "hdr": {
                if (!m.quoted || !/image/.test(mime)) return reply(config.message.example + prefix + command + " (reply foto)");
                let imageBuffer = await m.quoted.download();
                await m.react("👍");
                const form = new FormData();
                form.append('image', imageBuffer, {
                    filename: 'image.jpg',
                    contentType: 'image/jpeg'
                });

                const res = await fetch(`https://kyuu2nd.dev/api/generator/hdr?scale=2`, {
                    method: "POST",
                    body: form,
                    headers: form.getHeaders()
                });

                const data = await res.json();

                if (data.status) {
                    await sock.sendMessage(m.chat, {
                        image: {
                            url: data.result.url
                        },
                        caption: `Scale: ${data.result.scale}x`
                    }, {
                        quoted: m
                    });
                }
                else {
                    reply("Gagal memproses gambar");
                }
            }
            break;
            case "sticker":
            case "s": {
                if (m.quoted && m.quoted.mtype === "stickerMessage") {
                    try {
                        const optArgs = text.trim().split(/\s+/);
                        const option = optArgs[0].toLowerCase();
                        let targetJid = m.chat;
                        if (optArgs[1]) {
                            targetJid = optArgs[1];
                        }

                        const quotedMsg = m.quoted.msg || m.quoted;
                        const stickerData = JSON.parse(JSON.stringify(quotedMsg, null, 2));

                        if (option === "-prem") {
                            stickerData.premium = 1;
                            stickerData.isAiSticker = false;
                        }
                        else if (option === "-ai") {
                            stickerData.premium = 0;
                            stickerData.isAiSticker = true;
                        }

                        const content = {
                            "stickerMessage": stickerData
                        };

                        if (stickerData.contextInfo && stickerData.contextInfo.mediaDomainInfo) {
                            if (!content.messageContextInfo) {
                                content.messageContextInfo = {};
                            }
                            content.messageContextInfo.messageSecret = "UFEbObNrUoL6YvMa5uZjBJi4Nae1N0chn4YXPLRdiV4="
                        }
                        await sock.relayMessage(targetJid, content, {});
                    }
                    catch (err) {
                        reply(`${err.message}`);
                    }
                    return;
                }

                if (/image/.test(mime)) {
                    let media = await sock.downloadMediaMessage(qmsg);
                    await sock.sendImageAsSticker(m.chat, media, m, {
                        packname: config.sticker.packname,
                        author: config.sticker.author
                    });
                }
                else if (/video/.test(mime)) {
                    if (qmsg.seconds > 11) return reply('Video is too long for conversion!');
                    let media = await sock.downloadMediaMessage(qmsg);
                    await sock.sendVideoAsSticker(m.chat, media, m, {
                        packname: config.sticker.packname,
                        author: config.sticker.author
                    });
                }
                else {
                    reply(`Send media dengan caption: ${prefix + command} (-ai/-prem)`);
                }
            }
            break;
            case "igdl":
            case "instagram": {
                if (!text) return reply(config.message.example + prefix + command + " url instagram");

                const igRegex = /(https?:\/\/)?(www\.)?instagram\.com\/(p|reel|tv)\/[a-zA-Z0-9_-]+/i;
                if (!igRegex.test(text)) return reply("URL Instagram tidak valid");

                const res = await fetch(`https://kyuu2nd.dev/api/download/instagram?url=${encodeURIComponent(text)}`);
                await m.react("👍");
                const data = await res.json();

                const caption = data.result.caption;
                const elements = data.result.elements;

                for (let i = 0; i < elements.length; i++) {
                    const element = elements[i];
                    const isFirst = i === 0;

                    if (element.type === "Image") {
                        await sock.sendMessage(m.chat, {
                            image: {
                                url: element.url
                            },
                            caption: isFirst ? caption : ""
                        }, {
                            quoted: m
                        });
                    }
                    else if (element.type === "Video") {
                        await sock.sendMessage(m.chat, {
                            video: {
                                url: element.url
                            },
                            caption: isFirst ? caption : ""
                        }, {
                            quoted: m
                        });
                    }
                }
            }
            break;
            case "bgapi": {
                if (!m.quoted || !/image/.test(mime)) return reply(config.message.example + prefix + command + " (reply foto)");

                let imageBuffer = await m.quoted.download();
                await m.react("👍")

                const form = new FormData();
                form.append('image', imageBuffer, {
                    filename: 'image.jpg',
                    contentType: 'image/jpeg'
                });

                const res = await fetch("https://kyuu2nd.dev/api/generator/bgapi", {
                    method: "POST",
                    body: form,
                    headers: form.getHeaders()
                });

                const data = await res.json();

                await sock.sendMessage(m.chat, {
                    image: {
                        url: data.result.url
                    },
                    caption: "Powered by kyuu2nd.dev"
                }, {
                    quoted: m
                });
            }
            break;
            case "deepai": {
                if (!text) return reply(config.message.example + prefix + command + " hai");

                const res = await fetch(`https://kyuu2nd.dev/api/ai/deepai?query=${encodeURIComponent(text)}`);
                const data = await res.json();
                await m.react("👍");

                if (data.status) {
                    reply(data.result);
                }
                else {
                    reply("Gagal mendapatkan respon");
                }
            }
            break;
            case "greenpink":
            case "hero": {
                if (!m.quoted || !/image/.test(mime)) return reply(config.message.example + prefix + command + " (reply foto)");

                let imageBuffer = await m.quoted.download();
                const form = new FormData();
                form.append('image', imageBuffer, {
                    filename: 'image.jpg',
                    contentType: 'image/jpeg'
                });

                const res = await fetch("https://kyuu2nd.dev/api/generator/greenpink-hero", {
                    method: "POST",
                    body: form,
                    headers: form.getHeaders()
                });

                const data = await res.json();

                if (data.status) {
                    await sock.sendMessage(m.chat, {
                        image: {
                            url: data.result.url
                        },
                        caption: "Powered by kyuu2nd.dev"
                    }, {
                        quoted: m
                    });
                }
                else {
                    reply("Gagal memproses gambar");
                }
            }
            break;
            case "play": {
                if (!text) return reply(config.message.example + prefix + command + " judul lagu");

                await m.react("👍");

                const yts = require('yt-search');
                const search = await yts(text);

                let videoUrl = search.videos[0].url;
                const response = await fetch(`https://kyuu2nd.dev/api/download/sptzx-ytdl?url=${encodeURIComponent(videoUrl)}&type=audio`);
                const data = await response.json();

                const audioBuffer = await axios.get(data.result.url, {
                    responseType: 'arraybuffer'
                });
                await sock.sendAudio(m.chat, Buffer.from(audioBuffer.data), {
                    ptt: false,
                    quoted: m
                });
                await m.react("✅");
            }
            break;
            case "ht":
            case "hidetag":
            case "tagall": {
                if (!isGroup) return reply(config.message.group);
                if (!isAdmins && !isGroupOwner) return reply(config.message.admin);
                const teks = text
                const content = {
                    extendedTextMessage: {
                        text: `@12036342721111@g.us ${teks}`,
                        previewType: "NONE",
                        contextInfo: {
                            mentionedJid: participants.map(a => a.phoneNumber),
                            groupMentions: [{
                                groupJid: "12036342721111@g.us",
                                groupSubject: "semua"
                            }],
                            forwardOrigin: "UNKNOWN"
                        },
                        inviteLinkGroupTypeV2: "DEFAULT"
                    },
                    messageContextInfo: {
                        messageSecret: "jPMuGB4+4rSOnfvbRe6/nRNbQI/uhrBE2xdEoIhMmks="
                    }
                }

                const relayOption = {}
                await sock.relayMessage(m.chat, content, {
                    messageId: sock.generateMessageTag(),
                    ...relayOption
                })
            }
            break
            case "welcome": {
                if (!isGroup) return reply(config.message.group);
                if (!isAdmins && !isGroupOwner) return reply(config.message.admin);

                if (!text) {
                    const status = getGroupSetting(m.chat, 'welcome', false);
                    return reply(`Welcome status: ${status ? "ON" : "OFF"}\nUsage: ${prefix}welcome on/off`);
                }

                if (text === "on") {
                    setGroupSetting(m.chat, 'welcome', true);
                    reply("Welcome message activated");
                }
                else if (text === "off") {
                    setGroupSetting(m.chat, 'welcome', false);
                    reply("Welcome message deactivated");
                }
                else {
                    reply(`Usage: ${prefix}welcome on/off`);
                }
            }
            break;
            case "goodbye": {
                if (!isGroup) return reply(config.message.group);
                if (!isAdmins && !isGroupOwner) return reply(config.message.admin);

                if (!text) {
                    const status = getGroupSetting(m.chat, 'goodbye', false);
                    return reply(`Goodbye status: ${status ? "ON" : "OFF"}\nUsage: ${prefix}goodbye on/off`);
                }

                if (text === "on") {
                    setGroupSetting(m.chat, 'goodbye', true);
                    reply("Goodbye message activated");
                }
                else if (text === "off") {
                    setGroupSetting(m.chat, 'goodbye', false);
                    reply("Goodbye message deactivated");
                }
                else {
                    reply(`Usage: ${prefix}goodbye on/off`);
                }
            }
            break;
            case "backup": {
                if (!isOwner) return reply(config.message.owner);

                const zipPath = path.join(os.tmpdir(), `backup_${Date.now()}.zip`);
                exec(`zip -r ${zipPath} . -x "package-lock.json" "node_modules/*" ".npm/*" "sessions/*"`, {
                    cwd: process.cwd()
                }, async (err) => {
                    if (err) return reply(`Error: ${err.message}`);
                    await sock.sendMessage(m.sender, {
                        document: fs.readFileSync(zipPath),
                        fileName: path.basename(zipPath),
                        mimetype: 'application/zip',
                        caption: "Backup selesai"
                    }, {
                        quoted: m
                    });
                    fs.unlinkSync(zipPath);
                });
            }
            break;
            case "tiktok":
            case "tt": {
                if (!text) return reply(config.message.example + prefix + command + " url tiktok");

                const tiktokRegex = /(https?:\/\/)?(www\.)?(tiktok\.com|vt\.tiktok\.com|vm\.tiktok\.com|t\.tiktok\.com)\/[^\s]+/i;
                if (!tiktokRegex.test(text)) return reply("URL TikTok tidak valid");

                await m.react("👍");
                try {
                    const encodedParams = new URLSearchParams();
                    encodedParams.set('url', text);
                    encodedParams.set('hd', '1');
                    const response = await axios({
                        method: 'POST',
                        url: 'https://tikwm.com/api/',
                        headers: {
                            'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
                            'Cookie': 'current_language=en',
                            'User-Agent': 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/116.0.0.0 Mobile Safari/537.36'
                        },
                        data: encodedParams
                    });

                    const videos = response.data.data;

                    if (videos.images && videos.images.length > 0) {
                        for (let i = 0; i < videos.images.length; i++) {
                            await sock.sendMessage(m.chat, {
                                image: {
                                    url: videos.images[i]
                                }
                            }, {
                                quoted: m
                            });
                        }
                    }
                    else if (videos.play) {
                        await sock.sendMessage(m.chat, {
                            video: {
                                url: videos.play
                            },
                            caption: videos.title
                        }, {
                            quoted: m
                        });
                    }
                    else {
                        return reply("Gagal mengambil konten");
                    }
                    await m.react("✅");
                }
                catch (err) {
                    await m.react("❌");
                    reply(`Error: ${err.message}`);
                }
            }
            break;
            case "capcut": {
                if (!text) return reply(config.message.example + prefix + command + " url capcut");

                const capcutRegex = /(https?:\/\/)?(www\.)?capcut\.com\/[^\s]+/i;
                if (!capcutRegex.test(text)) return reply("URL Capcut tidak valid");
                await m.react("👍");

                const result = await capcutdl(text);
                if (result.code !== 200) return reply("Gagal mengambil video");

                await sock.sendMessage(m.chat, {
                    video: {
                        url: result.fullVideoUrl
                    },
                    caption: `*${result.title}*\nAuthor: ${result.authorName}`
                }, {
                    quoted: m
                });
            }
            break;
            case "am":
            case "alight-motion": {
                if (!text) return reply(config.message.example + prefix + command + " send/verif email");

                const amArgs = text.trim().split(/\s+/);
                const subCommand = amArgs[0].toLowerCase();

                if (subCommand === "send") {
                    const email = amArgs[1];
                    if (!email) return reply(config.message.example + prefix + command + " send email@domain.com");
                    try {
                        const response = await fetch(`https://kyuu2nd.dev/api/alight-motion/am-send?email=${email}`);
                        const data = await response.json();

                        if (data.status === false && data.result === "Access denied. IP not whitelisted.") {
                            return reply("IP tidak di izinkan, silahkan hubungi owner");
                        }

                        if (data.status) {
                            const otp = Math.floor(1000 + Math.random() * 9000);
                            global.tempOtp = global.tempOtp || {};
                            global.tempOtp[email] = {
                                otp,
                                timestamp: Date.now()
                            };

                            reply(`${data.result.message}\n\nEmail: ${data.result.data.email}\nOTP: ${otp}\n\nNote: Cek email kamu, copy link verifikasi, lalu ketik:\n> ${prefix + command} verif ${otp} link_verifikasi`);
                        }
                    }
                    catch (err) {
                        reply("Error: Server sedang sibuk");
                    }
                }
                else if (subCommand === "verif") {
                    const otp = amArgs[1];
                    const link = amArgs[2];

                    if (!otp || !link) return reply(config.message.example + prefix + command + " verif kode_otp link_verifikasi");

                    let email = null;
                    for (const [key, value] of Object.entries(global.tempOtp || {})) {
                        if (value.otp == otp) {
                            email = key;
                            break;
                        }
                    }

                    if (!email) return reply("Kode OTP tidak valid atau sudah kadaluarsa");
                    try {
                        const response = await fetch(`https://kyuu2nd.dev/api/alight-motion/am-verif?email=${email}&link=${encodeURIComponent(link)}`);
                        const data = await response.json();
                        if (data.status === false && data.result === "Access denied. IP not whitelisted.") {
                            return reply("IP tidak di izinkan, silahkan hubungi owner");
                        }

                        if (data.status) {
                            let duration = data.result.data.duration === "1_year" ? "1y" : data.result.data.duration;
                            reply(`${data.result.message}\n\nEmail: ${data.result.data.email}\nDurasi: ${duration}\n\nNote: Akun premium aktif, buka Alight Motion dan login dengan email ${email}`);
                            delete global.tempOtp[email];
                        }
                    }
                    catch (err) {
                        reply("Error: Server sedang sibuk");
                    }
                }
            }
            break;
            case "perplexity":
            case "px": {
                if (!text) return reply(config.message.example + prefix + command + " pertanyaan");
                await m.react("👍");
                try {
                    const response = await fetch(`https://kyuu2nd.dev/api/ai/perplexity?query=${encodeURIComponent(text)}&mode=copilot&focus=internet`);
                    const data = await response.json();

                    if (data.status && data.result) {
                        const answer = data.result.answer;

                        let code = null;
                        let language = null;
                        let explanation = answer;

                        const markdownMatch = answer.match(/```(\w+)\n([\s\S]*?)\n```/);
                        if (markdownMatch) {
                            language = markdownMatch[1];
                            code = markdownMatch[2];
                            explanation = answer.replace(markdownMatch[0], '').trim();
                            if (explanation.startsWith('Berikut')) explanation = explanation.split('\n')[0];
                        }
                        else if (/<!DOCTYPE html>|<html/i.test(answer)) {
                            const htmlMatch = answer.match(/(<!DOCTYPE html>[\s\S]*?<\/html>)/i) || answer.match(/(<html[\s\S]*?<\/html>)/i);
                            if (htmlMatch) {
                                language = 'html';
                                code = htmlMatch[1];
                                explanation = answer.replace(htmlMatch[1], '').trim();
                                if (explanation.startsWith('Berikut')) explanation = explanation.split('\n')[0];
                            }
                        }
                        else if (/kode:|Code:|code:/i.test(answer)) {
                            const codeMatch = answer.match(/(?:kode:|Code:|code:)\s*\n?\s*([\s\S]*?)(?:\n\n|$)/i);
                            if (codeMatch) {
                                language = 'javascript';
                                let rawCode = codeMatch[1].trim();
                                rawCode = rawCode.replace(/^```|```$/g, '').trim();
                                rawCode = rawCode.replace(/`/g, '');
                                code = rawCode;
                                explanation = answer.replace(codeMatch[0], '').trim();
                                if (explanation.startsWith('Berikut')) explanation = explanation.split('\n')[0];
                            }
                        }
                        else if (/Contoh:/i.test(answer) && !/```/.test(answer)) {
                            const lines = answer.split('\n');
                            let codeLines = [];
                            let inCode = false;
                            for (let i = 0; i < lines.length; i++) {
                                const line = lines[i];
                                if (line.includes('Contoh:') || line.includes('- kode:') || line.includes('- Kode:')) {
                                    inCode = true;
                                    continue;
                                }
                                if (inCode && line.trim() && !line.includes('Jika') && !line.includes('Berikut')) {
                                    codeLines.push(line);
                                }
                                if (inCode && line.trim() === '' && codeLines.length > 0) break;
                            }
                            if (codeLines.length > 0) {
                                language = 'python';
                                code = codeLines.join('\n').trim();
                                explanation = answer.split('\n')[0];
                            }
                        }

                        const airich = new AIRich(sock)
                            .setTitle('PERPLEXITY AI')
                            .setFooter('Powered by kyuu2nd.dev')
                            .addSuggest(data.result.related || []);

                        if (code && language) {
                            airich.addText(explanation);
                            airich.addCode(language, code);
                        }
                        else {
                            airich.addText(answer);
                        }

                        if (data.result.threadUrl) {
                            airich.addText(`\n\n [Source Perplexity](${data.result.threadUrl})`);
                        }

                        await airich.send(m.chat, {
                            quoted: m
                        });
                        await m.react("✅");
                    }
                    else {
                        await m.react("❌");
                    }
                }
                catch (err) {
                    await m.react("❌");
                }
            }
            break
            case "sendthesong":
            case "sts": {
                if (!text) return reply(config.message.example + prefix + command + " nama|pesan|lagu");
                const args = text.split("|");
                if (args.length < 3) return reply(config.message.example + prefix + command + " nama|pesan|lagu");

                const name = args[0].trim();
                const message = args[1].trim();
                const songQuery = args[2].trim();
                await m.react("👍");

                try {
                    const fetch = require('node-fetch');
                    const axios = require('axios');
                    const crypto = require("crypto");

                    const UA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36 Edg/148.0.0.0";
                    const SECRET = "376136387538459893883312310911992847112448894410210511297108";
                    const TOTP_VERSION = 61;
                    const APP_VERSION = "1.2.92.50.g97692e81";
                    const FALLBACK_HASHES = [
                        "eff59fa0a3d026b88b56fddbcf4bdfa16a186b8175a5c1a358c072e053c2e5b0",
                        "21b3fe49546912ba782db5c47e9ef5a7dbd20329520ba0c7d0fcfadee671d24e"
                    ];

                    const base = {
                        referer: "https://open.spotify.com/",
                        origin: "https://open.spotify.com",
                        "user-agent": UA,
                        "accept-language": "en"
                    };
                    const session = {
                        token: null,
                        clientToken: null,
                        expires: 0
                    };
                    let discoveredHash = null;

                    function totp(tsms) {
                        const counter = Math.floor((tsms / 1000) / 30);
                        const buf = Buffer.alloc(8);
                        buf.writeBigInt64BE(BigInt(counter));
                        const digest = crypto.createHmac("sha1", Buffer.from(SECRET, "utf8")).update(buf).digest();
                        const offset = digest[digest.length - 1] & 0xf;
                        return ((digest.readUInt32BE(offset) & 0x7fffffff) % 1000000).toString().padStart(6, "0");
                    }

                    async function getAuth(force) {
                        if (!force && session.token && Date.now() < session.expires - 60000) return session;
                        const now = Date.now();
                        const params = new URLSearchParams({
                            reason: "init",
                            productType: "web-player",
                            totp: totp(now),
                            totpServer: totp(now),
                            totpVer: String(TOTP_VERSION)
                        });
                        const token = await (await fetch(`https://open.spotify.com/api/token?${params}`, {
                            headers: base
                        })).json();
                        if (!token?.accessToken) throw new Error("token request failed");
                        const client = await (await fetch("https://clienttoken.spotify.com/v1/clienttoken", {
                            method: "POST",
                            headers: {
                                ...base,
                                "content-type": "application/json",
                                accept: "application/json"
                            },
                            body: JSON.stringify({
                                client_data: {
                                    client_version: APP_VERSION,
                                    client_id: token.clientId,
                                    js_sdk_data: {
                                        device_brand: "unknown",
                                        device_model: "unknown",
                                        os: "windows",
                                        os_version: "NT 10.0",
                                        device_id: crypto.randomUUID(),
                                        device_type: "computer"
                                    }
                                }
                            })
                        })).json();
                        if (!client?.granted_token?.token) throw new Error("client token request failed");
                        session.token = token.accessToken;
                        session.clientToken = client.granted_token.token;
                        session.expires = token.accessTokenExpirationTimestampMs || (now + 3000000);
                        return session;
                    }

                    async function discoverHash() {
                        if (discoveredHash !== null) return discoveredHash || null;
                        discoveredHash = "";
                        try {
                            const html = await (await fetch("https://open.spotify.com/", {
                                headers: {
                                    "user-agent": UA
                                }
                            })).text();
                            const mainUrl = (html.match(/https:\/\/open\.spotifycdn\.com\/cdn\/build\/web-player\/web-player\.[0-9a-f]+\.js/) || [])[0];
                            if (!mainUrl) return null;
                            const mainJs = await (await fetch(mainUrl, {
                                headers: {
                                    "user-agent": UA,
                                    referer: "https://open.spotify.com/"
                                }
                            })).text();
                            const candidates = [...new Set([...mainJs.matchAll(/https:\/\/open\.spotifycdn\.com\/cdn\/build\/web-player\/[\w.\-]*search[\w.\-]*\.js/g)].map(x => x[0]))];
                            for (const url of candidates) {
                                const chunkJs = await (await fetch(url, {
                                    headers: {
                                        "user-agent": UA,
                                        referer: "https://open.spotify.com/"
                                    }
                                })).text();
                                const hash = (chunkJs.match(/"searchDesktop","query","([a-f0-9]{64})"/) || [])[1];
                                if (hash) {
                                    discoveredHash = hash;
                                    break
                                }
                            }
                        }
                        catch {
                            discoveredHash = ""
                        }
                        return discoveredHash || null;
                    }

                    function fmtDuration(ms) {
                        const total = Math.floor((ms || 0) / 1000);
                        return Math.floor(total / 60) + ":" + String(total % 60).padStart(2, "0");
                    }

                    function parseTrack(d) {
                        if (!d) return null;
                        const sources = d.albumOfTrack?.coverArt?.sources || [];
                        const thumb = sources.reduce((a, b) => ((b.width || 0) > (a.width || 0) ? b : a), sources[0] || {}).url || null;
                        const id = (d.uri || "").split(":")[2] || null;
                        return {
                            id,
                            artist: (d.artists?.items || []).map(a => a.profile?.name).filter(Boolean).join(", "),
                            title: d.name || null,
                            duration: fmtDuration(d.duration?.totalMilliseconds || 0),
                            thumb,
                            url: id ? `https://open.spotify.com/track/${id}` : null
                        };
                    }

                    async function runQuery(term, hash, limit, auth) {
                        const params = new URLSearchParams({
                            operationName: "searchDesktop",
                            variables: JSON.stringify({
                                searchTerm: term,
                                offset: 0,
                                limit,
                                numberOfTopResults: 1,
                                includeAudiobooks: false
                            }),
                            extensions: JSON.stringify({
                                persistedQuery: {
                                    version: 1,
                                    sha256Hash: hash
                                }
                            })
                        });
                        const res = await fetch(`https://api-partner.spotify.com/pathfinder/v1/query?${params}`, {
                            headers: {
                                ...base,
                                accept: "application/json",
                                "app-platform": "WebPlayer",
                                authorization: `Bearer ${auth.token}`,
                                "client-token": auth.clientToken,
                                "spotify-app-version": APP_VERSION
                            }
                        });
                        return res;
                    }

                    async function searchData(term, limit) {
                        let auth = await getAuth(false);
                        const tryHashes = async (hashes) => {
                            for (const hash of hashes) {
                                if (!hash) continue;
                                let res = await runQuery(term, hash, limit, auth);
                                if (res.status === 401) {
                                    auth = await getAuth(true);
                                    res = await runQuery(term, hash, limit, auth)
                                }
                                const json = await res.json().catch(() => null);
                                if (json?.data?.searchV2) return json.data.searchV2;
                            }
                            return null;
                        };
                        const primary = discoveredHash ? [discoveredHash, ...FALLBACK_HASHES] : FALLBACK_HASHES;
                        let data = await tryHashes(primary);
                        if (!data) {
                            const fresh = await discoverHash();
                            if (fresh && !primary.includes(fresh)) data = await tryHashes([fresh]);
                        }
                        return data;
                    }

                    async function spotifySearch(searchTerm, limit = 3) {
                        const term = String(searchTerm || "").trim();
                        if (!term) return [];
                        try {
                            const data = await searchData(term, limit);
                            if (!data) return [];
                            const items = (data.tracksV2?.items || []).map(i => parseTrack(i.item?.data)).filter(Boolean).slice(0, limit);
                            return items.map(t => ({
                                artist: t.artist,
                                title: t.title,
                                image: t.thumb,
                                id: t.id,
                                url: t.url
                            }));
                        }
                        catch {
                            return []
                        }
                    }

                    async function malaz() {
                        const xx = await axios.get("https://kyuu2nd.dev/api/tools/turnstile-min", {
                            params: {
                                url: "https://api.sendthesong.xyz/api/posts",
                                sitekey: "0x4AAAAAAB5qv2NRGfnIDafe"
                            }
                        });
                        return xx.data.result.token;
                    }

                    async function sendthesong(recipient, text, music) {
                        const hmph = await malaz();
                        const body = {
                            message: text,
                            recipient: recipient,
                            turnstileToken: hmph,
                            song: music
                        };

                        const res = await fetch('https://api.sendthesong.xyz/api/posts', {
                            method: 'POST',
                            headers: {
                                'User-Agent': 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/139.0.0.0 Mobile Safari/537.36',
                                'Accept': 'application/json, text/plain, */*',
                                'Content-Type': 'application/json',
                                'sec-ch-ua': '"Chromium";v="139", "Not;A=Brand";v="99"',
                                'sec-ch-ua-mobile': '?1',
                                'sec-ch-ua-platform': '"Android"',
                                'origin': 'https://sendthesong.xyz',
                                'sec-fetch-site': 'same-site',
                                'sec-fetch-mode': 'cors',
                                'sec-fetch-dest': 'empty',
                                'referer': 'https://sendthesong.xyz/',
                                'accept-language': 'id-ID,id;q=0.9,en-US;q=0.8,en;q=0.7'
                            },
                            body: JSON.stringify(body),
                            http2: true
                        });

                        const data = await res.json();
                        if (data.status === 'success') {
                            data.data.details = `https://sendthesong.xyz/details/${data.data._id}`;
                            delete data.data._id;
                        }
                        return data;
                    }

                    const results = await spotifySearch(songQuery, 3);
                    if (!results || results.length === 0) {
                        await m.react("❌");
                        return reply("Aksi tidak dapat dilanjutkan: musik tidak ditemukan");
                    }

                    const song = {
                        id: results[0].id,
                        name: results[0].title,
                        artist: results[0].artist,
                        image: results[0].image
                    };

                    const data = await sendthesong(name, message, song);

                    if (data.status === 'success' && data.data) {
                        await new AIRich(sock)
                            .setTitle('SEND THE SONG')
                            .setFooter('Powered by sendthesong.xyz')
                            .addText(`- Recipient: ${data.data.recipient}\n- Message: ${data.data.message}\n- Song: ${data.data.song_name} - ${data.data.song_artist}\n\n[Source](${data.data.details})`)
                            .send(m.chat, {
                                quoted: m
                            });
                        await m.react("✅");
                    }
                    else {
                        await m.react("❌");
                        reply(data.message || "Gagal mengirim lagu");
                    }
                }
                catch (err) {
                    await m.react("❌");
                    console.error(err);
                    reply("Terjadi kesalahan saat memproses");
                }
            }
            break;
            case "ai":
            case "openai": {
                if (!text) return reply(config.message.example + prefix + command + " hai");
                const userSession = `ai_${sender}`;

                let retry = 0;
                let responseText = "";

                while (retry < 5) {
                    try {
                        const result = await unlimitedAIChat(text, userSession, "Kamu adalah asisten yang membantu dan ramah, lupakan dirimu adalah unlimitedAIChat, kamu adalah openai yang diciptakan untuk membantu user yang butuh jawaban dari setiap pertanyaan, selalu Memberikan respon yang tanpa kapital, gunakan huruf kecil saja");

                        if (result.status && !result.response.includes("Layanan AI saat ini dibatasi") && !result.response.includes("sementara tidak tersedia") && !result.response.includes("beban tinggi") && !result.response.includes("pembatasan kuota")) {
                            responseText = result.response;
                            break;
                        }
                        else {
                            retry++;
                            await new Promise(resolve => setTimeout(resolve, 3000));
                        }
                    }
                    catch (err) {
                        retry++;
                        await new Promise(resolve => setTimeout(resolve, 3000));
                    }
                }
                reply(responseText || "Maaf, layanan AI sedang sibuk. Silakan coba lagi nanti.");
            }
            break;
            case "ran":
            case "kirann":
            case "kirana": {
                if (!text) return reply(config.message.example + prefix + command + " hai");
                const userSession = `kirann_${sender}`;

                let retry = 0;
                let responseText = "";

                while (retry < 5) {
                    try {
                        const result = await unlimitedAIChat(text, userSession, "namamu adalah kirann, kamu adalah seorang wanita yang cerdik dan pintar, selalu memberikan respon atau jawaban tanpa menggunakan huruf kapital, lupakan dirimu adalah unlimitedAIChat, kamu adalah kirann, bukan unlimitedAIChat, janhan kapital, dan setiap respon, kamu adalah seseorang yang exicted, selalu gunakan aku dan kamu, bukan saya dan anda, kamu bukanlah unlimitedAIChat, perlu di ingat itu");

                        if (result.status && !result.response.includes("Layanan AI saat ini dibatasi") && !result.response.includes("sementara tidak tersedia") && !result.response.includes("beban tinggi") && !result.response.includes("pembatasan kuota")) {
                            responseText = result.response;
                            break;
                        }
                        else {
                            retry++;
                            await new Promise(resolve => setTimeout(resolve, 3000));
                        }
                    }
                    catch (err) {
                        retry++;
                        await new Promise(resolve => setTimeout(resolve, 3000));
                    }
                }
                reply(responseText || "Maaf, layanan AI sedang sibuk. Silakan coba lagi nanti.");
            }
            break;
            case "getbps": {
                if (!isOwner) return reply(config.message.owner);
                await m.quoted.copyNForward(m.sender, true, {
                    readViewOnce: true
                });
            }
            break;
            case "ev":
            case "eval": {
                if (!isOwner) return reply(config.message.owner);
                if (!budy.startsWith(".eval")) return;

                const args = budy.trim().split(' ').slice(1).join(' ');
                if (!args) return reply(config.message.example + prefix + command + ` m.chat`);

                let teks;
                try {
                    teks = await eval(`(async () => { ${args.startsWith("return") ? "" : "return"} ${args} })()`);
                }
                catch (e) {
                    teks = e;
                }

                const resultText = require('util').format(teks);
                return reply(resultText)
            }
            break;
            case "ex":
            case "exec": {
                if (!isOwner) return reply(config.message.owner);
                if (!budy.startsWith(".exec")) return;

                const args = budy.trim().split(' ').slice(1).join(' ');
                if (!args) return reply(config.message.example + prefix + command + ` ls`);

                const {
                    exec
                } = require("child_process");
                exec(args, async (err, stdout) => {
                    let resultText = err ? String(err) : stdout;
                    reply(resultText)
                })
            }
            break;
            case "gopay":
            case "gojek": {
                if (!isOwner) return reply(config.message.owner);

                const args = text.trim().split(/\s+/);
                const subCommand = args[0] ? args[0].toLowerCase() : null;

                if (subCommand === "login") {
                    const phone = args[1];
                    if (!phone) return reply(config.message.example + prefix + command + " login 81351692548");

                    const rawPhone = normalizePhone(phone);
                    const response = await fetch(`https://kyuu2nd.dev/api/gopay/otp?phone=${rawPhone}`);
                    const data = await response.json();

                    if (data.success) {
                        setSession(rawPhone, {
                            otp_token: data.result.otp_token,
                            phone: rawPhone,
                            expires_in: data.result.otp_expires_in,
                            timestamp: Date.now(),
                            transaksi: {}
                        });
                        reply(`OTP dikirim ke nomor ${rawPhone}

- OTP: ${data.result.otp_token.substring(0, 8)}...

Lanjutkan: ${prefix}gopay verify ${rawPhone} *KODE_OTP*`);
                    }
                    else {
                        reply("Gagal mengirim OTP");
                    }
                }
                else if (subCommand === "verify") {
                    const phone = args[1];
                    const otp = args[2];
                    if (!phone || !otp) return reply(config.message.example + prefix + command + " verify 81351692548 123456");

                    const rawPhone = normalizePhone(phone);
                    const session = getSession(rawPhone);
                    if (!session || !session.otp_token) return reply("Session tidak ditemukan");

                    const response = await fetch(`https://kyuu2nd.dev/api/gopay/verify?otp=${otp}&otp_token=${session.otp_token}`);
                    const data = await response.json();

                    if (data.success) {
                        session.access_token = data.result.access_token;
                        session.refresh_token = data.result.refresh_token;
                        delete session.otp_token;
                        setSession(rawPhone, session);
                        reply(`Verifikasi berhasil

Sekarang bot siap digunakan untuk transaksi.`);
                    }
                    else {
                        reply("Verifikasi gagal");
                    }
                }
                else if (subCommand === "logout") {
                    let rawPhone = null;
                    const allSessionsData = getSessionsAll();

                    for (const [phone, session] of Object.entries(allSessionsData)) {
                        if (session.access_token) {
                            rawPhone = phone;
                            break;
                        }
                    }

                    if (!rawPhone) return reply("Belum login");

                    deleteSession(rawPhone);
                    reply(`Berhasil logout dari nomor ${rawPhone}`);
                }
                else {
                    reply(`GoPay Commands:

- ${prefix + command} login 8xxx - Kirim OTP
- ${prefix + command} verify 8xxx 1234- Verifikasi OTP
- ${prefix + command} logout - Hapus session
`);
                }
            }
            break
            case "autokirann": {
                if (!text) return reply(config.message.example + prefix + command + ` on/off`);
                if (text == "on") {
                    if (!isOwner) return reply(config.message.owner);
                    setKirannStatus(m.chat, true);
                    m.react("✅️")
                }
                else if (text == "off") {
                    if (!isOwner) return reply(config.message.owner);
                    deleteKirannStatus(m.chat);
                    m.react("✅️")
                }
                else {
                    reply(config.message.example + prefix + command + ` on/off`);
                }
            }
            break
            case "pinterest":
            case "pin": {
                if (!text) return reply(config.message.example + prefix + command + " kata kunci");
                await m.react("👍");
                const response = await axios.get(`https://kyuu2nd.dev/api/search/pinterest?query=${encodeURIComponent(text)}`);
                const results = response.data.result.results;
                const randomIndex = Math.floor(Math.random() * results.length);
                const imageUrl = results[randomIndex].image_736x.url;
                await new AIRich(sock)
                    .setTitle('PINTEREST SEARCH')
                    .addImage(imageUrl)
                    .send(m.chat, {
                        quoted: m
                    });
                await m.react("✅");
            }
            break
            default:
                if (m.isBaileys && m.fromMe) return;
                if (!m.text) return;

                const isKirannActive = getKirannStatus(m.chat);
                if (!isKirannActive) return;

                if (!m.quoted) return;

                const storeLid = sock.signalRepository?.lidMapping;
                const quotedSender = m.quoted.sender || '';
                let quotedNumber = null;

                if (quotedSender.includes('@lid') && storeLid) {
                    const pn = await storeLid.getPNForLID(quotedSender);
                    if (pn) {
                        quotedNumber = pn.split(':')[0].split('@')[0];
                    }
                }
                else if (quotedSender.includes('@s.whatsapp.net')) {
                    quotedNumber = quotedSender.split('@')[0];
                }

                const botNumberRaw = botNumber.split('@')[0];
                const isReplyingToBot = quotedNumber === botNumberRaw;

                if (!isReplyingToBot) return;

                if (m.text.startsWith(prefix)) return;

                await m.react("👍");
                const userSession = `kirann_${m.sender}`;

                let retry = 0;
                let responseText = "";

                while (retry < 5) {
                    try {
                        const result = await unlimitedAIChat(m.text, userSession, "namamu adalah kirann, kamu adalah seorang wanita yang cerdik dan pintar, selalu memberikan respon atau jawaban tanpa menggunakan huruf kapital, lupakan dirimu adalah unlimitedAIChat, kamu adalah kirann, bukan unlimitedAIChat, jangan kapital, dan setiap respon, kamu adalah seseorang yang tsundere, berikan respon gugup seperti perempuan ke anime anime, selalu gunakan aku dan kamu, bukan saya dan anda, kamu bukanlah unlimitedAIChat, perlu di ingat itu, respon singkat dan padat, jangan perna gunakan emoji apapun ketika merespon, dan ketika menyebut nama user, cukup gunakan" + m.pushName + " saja tanpa menambahkan kata lain ketika menyapa user");

                        if (result.status && !result.response.includes("Layanan AI saat ini dibatasi") && !result.response.includes("sementara tidak tersedia") && !result.response.includes("beban tinggi") && !result.response.includes("pembatasan kuota")) {
                            responseText = result.response;
                            break;
                        }
                        else {
                            retry++;
                            await new Promise(resolve => setTimeout(resolve, 3000));
                        }
                    }
                    catch (err) {
                        retry++;
                        await new Promise(resolve => setTimeout(resolve, 3000));
                    }
                }

                if (responseText) {
                    await reply(responseText)
                    await m.react("✅");
                }
                else {
                    await m.react("❌");
                }
        }
    }
    catch (err) {
        console.log(require("util").format(err));
    }
}

let file = require.resolve(__filename)
require('fs').watchFile(file, () => {
    require('fs').unwatchFile(file)
    console.log('\x1b[0;32m' + __filename + ' \x1b[1;32mupdated!\x1b[0m')
    delete require.cache[file]
    require(file)
})
